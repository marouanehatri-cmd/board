# No reflection is used; default rules are enough.
