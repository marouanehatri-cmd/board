package com.huaweikeyboard.fix

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/** Clipboard history (text + screenshots) with pinning. Stored app-private (no backup). */
class ClipStore(context: Context) {

    companion object {
        private const val MAX_UNPINNED = 30
        private const val MAX_TEXT = 20_000
        private const val KEY = "items"
    }

    private val prefs = context.getSharedPreferences("clip_store", Context.MODE_PRIVATE)
    private val cacheDir = File(context.filesDir, "screenshots")
    private val items = mutableListOf<ClipItem>()

    @Volatile
    var onChanged: (() -> Unit)? = null

    init {
        load()
        // Remove cached files nobody references anymore.
        cacheDir.listFiles()?.forEach { f ->
            if (items.none { it.cachedName == f.name }) f.delete()
        }
    }

    @Synchronized
    fun snapshot(): List<ClipItem> =
        items.sortedWith(compareByDescending<ClipItem> { it.pinned }.thenByDescending { it.timestamp })

    @Synchronized
    fun addText(text: String) {
        if (text.isBlank() || text.length > MAX_TEXT) return
        val idx = items.indexOfFirst { it.type == ClipItem.Type.TEXT && it.text == text }
        if (idx >= 0) {
            val old = items.removeAt(idx)
            items.add(old.copy(timestamp = System.currentTimeMillis()))
        } else {
            items.add(ClipItem(UUID.randomUUID().toString(), ClipItem.Type.TEXT, text = text))
        }
        commit()
    }

    /** @return false if this MediaStore URI is already in history. */
    @Synchronized
    fun addImage(id: String, mediaUri: String, cachedName: String?): Boolean {
        if (items.any { it.mediaUri == mediaUri }) return false
        items.add(ClipItem(id, ClipItem.Type.IMAGE, mediaUri = mediaUri, cachedName = cachedName))
        commit()
        return true
    }

    @Synchronized
    fun updateCached(id: String, name: String) = replace(id) { it.copy(cachedName = name) }

    @Synchronized
    fun togglePin(id: String) = replace(id) { it.copy(pinned = !it.pinned) }

    @Synchronized
    fun clearUnpinned() {
        items.filter { !it.pinned }.forEach { discard(it) }
        commit()
    }

    private fun replace(id: String, f: (ClipItem) -> ClipItem) {
        val i = items.indexOfFirst { it.id == id }
        if (i >= 0) {
            items[i] = f(items[i])
            commit()
        }
    }

    private fun discard(item: ClipItem) {
        items.remove(item)
        item.cachedName?.let { File(cacheDir, it).delete() }
    }

    private fun commit() {
        items.filter { !it.pinned }
            .sortedByDescending { it.timestamp }
            .drop(MAX_UNPINNED)
            .forEach { discard(it) }
        save()
        onChanged?.invoke()
    }

    private fun save() {
        val arr = JSONArray()
        items.forEach {
            arr.put(JSONObject().apply {
                put("id", it.id)
                put("type", it.type.name)
                put("text", it.text)
                put("mediaUri", it.mediaUri)
                put("cachedName", it.cachedName)
                put("pinned", it.pinned)
                put("ts", it.timestamp)
            })
        }
        prefs.edit().putString(KEY, arr.toString()).apply()
    }

    private fun load() {
        val raw = prefs.getString(KEY, null) ?: return
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                items.add(
                    ClipItem(
                        id = o.getString("id"),
                        type = ClipItem.Type.valueOf(o.getString("type")),
                        text = o.optString("text").takeIf { it.isNotEmpty() },
                        mediaUri = o.optString("mediaUri").takeIf { it.isNotEmpty() },
                        cachedName = o.optString("cachedName").takeIf { it.isNotEmpty() },
                        pinned = o.optBoolean("pinned", false),
                        timestamp = o.optLong("ts", 0L)
                    )
                )
            }
        } catch (_: Exception) {
            items.clear()
        }
    }
}
