package com.huaweikeyboard.fix

import android.content.ClipData
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.util.Log
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import androidx.core.view.inputmethod.EditorInfoCompat
import androidx.core.view.inputmethod.InputConnectionCompat
import androidx.core.view.inputmethod.InputContentInfoCompat
import java.io.File

class ClipboardHelper(private val context: Context) {

    enum class PasteResult { PASTED, COPIED, FAILED }

    private companion object {
        const val TAG = "ClipboardHelper"
    }

    private val cm: ClipboardManager = context.getSystemService(ClipboardManager::class.java)
    private val resolver = context.contentResolver

    /** filesDir/screenshots: owned by this app, always readable by us, served through FileProvider. */
    val cacheDir: File = File(context.filesDir, "screenshots").apply { mkdirs() }

    fun uriFor(file: File): Uri =
        FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)

    fun mimeFor(file: File): String =
        MimeTypeMap.getSingleton().getMimeTypeFromExtension(file.extension.lowercase()) ?: "image/png"

    /** Copies the image bytes (lossless, no Bitmap re-encode) into our own folder. */
    fun cacheImage(source: Uri, id: String): String? = try {
        val ext = resolver.getType(source)
            ?.let { MimeTypeMap.getSingleton().getExtensionFromMimeType(it) } ?: "png"
        val name = "$id.$ext"
        val out = File(cacheDir, name)
        val input = resolver.openInputStream(source)
        if (input == null) {
            null
        } else {
            input.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
            if (out.length() > 0) name else { out.delete(); null }
        }
    } catch (e: Exception) { // SecurityException, FileNotFoundException, IOException
        Log.w(TAG, "cacheImage failed: ${e.javaClass.simpleName}")
        null
    }

    fun ensureCached(item: ClipItem): File? {
        item.cachedName?.let {
            val f = File(cacheDir, it)
            if (f.exists() && f.length() > 0) return f
        }
        val uri = item.mediaUri?.let(Uri::parse) ?: return null
        val name = cacheImage(uri, item.id) ?: return null
        return File(cacheDir, name)
    }

    /**
     * Puts the screenshot on the system clipboard.
     * 1) MediaStore URI (ClipData.newUri); 2) on SecurityException (Huawei without GMS),
     * the FileProvider URI of our own copy.
     */
    fun copyImageToClipboard(mediaUri: Uri, cached: File?): Boolean {
        if (cached != null && Prefs.preferOwnCopy(context)) return trySetClip(uriFor(cached))
        if (trySetClip(mediaUri)) return true
        return cached != null && trySetClip(uriFor(cached))
    }

    /**
     * Paste into the focused field. Best path: InputConnection.commitContent with a read grant
     * (works in editors that accept images). Otherwise put it on the clipboard.
     */
    fun paste(ic: InputConnection?, info: EditorInfo?, file: File): PasteResult {
        val uri = uriFor(file)
        val mime = mimeFor(file)
        if (ic != null && info != null) {
            val accepted = EditorInfoCompat.getContentMimeTypes(info)
            if (accepted.any { ClipDescription.compareMimeTypes(mime, it) }) {
                val content = InputContentInfoCompat(uri, ClipDescription("screenshot", arrayOf(mime)), null)
                val ok = InputConnectionCompat.commitContent(
                    ic, info, content, InputConnectionCompat.INPUT_CONTENT_GRANT_READ_URI_PERMISSION, null
                )
                if (ok) return PasteResult.PASTED
            }
        }
        return if (trySetClip(uri)) PasteResult.COPIED else PasteResult.FAILED
    }

    private fun trySetClip(uri: Uri): Boolean = try {
        cm.setPrimaryClip(ClipData.newUri(resolver, "screenshot", uri))
        true
    } catch (e: SecurityException) {
        Log.w(TAG, "setPrimaryClip denied for ${uri.authority}")
        false
    } catch (e: Exception) {
        Log.w(TAG, "setPrimaryClip failed: ${e.javaClass.simpleName}")
        false
    }
}
