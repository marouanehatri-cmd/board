package com.huaweikeyboard.fix

import android.content.Context

object Prefs {
    private const val FILE = "settings"
    private const val PREFER_OWN_COPY = "prefer_own_copy"

    fun preferOwnCopy(c: Context): Boolean =
        c.getSharedPreferences(FILE, Context.MODE_PRIVATE).getBoolean(PREFER_OWN_COPY, false)

    fun setPreferOwnCopy(c: Context, value: Boolean) {
        c.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putBoolean(PREFER_OWN_COPY, value).apply()
    }
}
