package com.huaweikeyboard.fix

import android.content.ContentUris
import android.content.Context
import android.database.ContentObserver
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.provider.MediaStore

/**
 * Watches MediaStore for freshly added images that look like screenshots
 * (name or folder contains "screenshot", e.g. Pictures/Screenshots on Huawei/Honor).
 */
class ScreenshotObserver(
    private val context: Context,
    handler: Handler,
    private val onScreenshot: (Uri) -> Unit
) : ContentObserver(handler) {

    private companion object {
        const val RECENT_SECONDS = 20L
    }

    private var lastId = -1L
    private val images: Uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI

    fun register() {
        context.contentResolver.registerContentObserver(images, true, this)
    }

    fun unregister() {
        context.contentResolver.unregisterContentObserver(this)
    }

    override fun onChange(selfChange: Boolean, uri: Uri?) {
        if (!Permissions.hasFullAccess(context)) return
        val id = findRecentScreenshotId() ?: return
        if (id == lastId) return
        lastId = id
        onScreenshot(ContentUris.withAppendedId(images, id))
    }

    private fun findRecentScreenshotId(): Long? {
        val pathCol = if (Build.VERSION.SDK_INT >= 29) MediaStore.MediaColumns.RELATIVE_PATH
        else MediaStore.MediaColumns.DATA
        val projection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            pathCol
        )
        val minAdded = System.currentTimeMillis() / 1000 - RECENT_SECONDS
        return try {
            context.contentResolver.query(
                images,
                projection,
                "${MediaStore.Images.Media.DATE_ADDED} >= ?",
                arrayOf(minAdded.toString()),
                "${MediaStore.Images.Media.DATE_ADDED} DESC"
            )?.use { c ->
                val idI = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                val nameI = c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
                val pathI = c.getColumnIndexOrThrow(pathCol)
                while (c.moveToNext()) {
                    val name = c.getString(nameI).orEmpty()
                    val path = c.getString(pathI).orEmpty()
                    if (name.contains("screenshot", true) || path.contains("screenshot", true)) {
                        return@use c.getLong(idI)
                    }
                }
                null
            }
        } catch (_: Exception) {
            null
        }
    }
}
