package com.huaweikeyboard.fix

import android.app.Activity
import android.os.Bundle
import androidx.core.app.ActivityCompat

/** Transparent activity: an InputMethodService can't show runtime-permission dialogs. */
class PermissionActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Permissions.hasFullAccess(this)) {
            finish()
            return
        }
        ActivityCompat.requestPermissions(this, Permissions.required(), 42)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        finish()
    }
}
