package com.huaweikeyboard.fix

data class ClipItem(
    val id: String,
    val type: Type,
    val text: String? = null,
    /** Original MediaStore content:// URI (images only). */
    val mediaUri: String? = null,
    /** File name inside filesDir/screenshots (our own copy), if already cached. */
    val cachedName: String? = null,
    val pinned: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
) {
    enum class Type { TEXT, IMAGE }
}
