package com.huaweikeyboard.fix

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

class SettingsActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        fun button(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { onClick() }
        }

        root.addView(button(getString(R.string.settings_enable)) {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        })
        root.addView(button(getString(R.string.settings_select)) {
            getSystemService(InputMethodManager::class.java).showInputMethodPicker()
        })
        root.addView(button(getString(R.string.settings_grant)) {
            startActivity(Intent(this, PermissionActivity::class.java))
        })
        root.addView(button(getString(R.string.settings_app_settings)) {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            )
        })

        status = TextView(this).apply { setPadding(0, pad, 0, pad) }
        root.addView(status)

        root.addView(Switch(this).apply {
            text = getString(R.string.settings_own_copy)
            isChecked = Prefs.preferOwnCopy(this@SettingsActivity)
            setOnCheckedChangeListener { _, checked -> Prefs.setPreferOwnCopy(this@SettingsActivity, checked) }
        })

        if (Permissions.isHuawei()) {
            root.addView(TextView(this).apply {
                text = getString(R.string.huawei_tip)
                setPadding(0, pad, 0, 0)
            })
        }

        setContentView(
            ScrollView(this).apply {
                addView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            }
        )
    }

    override fun onResume() {
        super.onResume()
        status.setText(if (Permissions.hasFullAccess(this)) R.string.status_ok else R.string.status_missing)
    }
}
