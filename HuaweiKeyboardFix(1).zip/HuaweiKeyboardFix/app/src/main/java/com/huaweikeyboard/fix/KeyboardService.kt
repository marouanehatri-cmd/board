package com.huaweikeyboard.fix

import android.annotation.SuppressLint
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.inputmethodservice.InputMethodService
import android.net.Uri
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.text.InputType
import android.text.TextUtils
import android.util.LruCache
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.util.UUID
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class KeyboardService : InputMethodService() {

    private enum class Shift { OFF, ONCE, LOCKED }
    private enum class Mode { LETTERS, SYMBOLS }

    private class Palette(night: Boolean) {
        val bg = c(if (night) 0xFF1B1B1F else 0xFFE8EAED)
        val key = c(if (night) 0xFF3A3B40 else 0xFFFFFFFF)
        val keyPressed = c(if (night) 0xFF5A5C63 else 0xFFC8CBD2)
        val special = c(if (night) 0xFF2A2B2F else 0xFFD3D6DC)
        val chip = c(if (night) 0xFF2C2D32 else 0xFFFFFFFF)
        val pinned = c(if (night) 0xFF3B4F7A else 0xFFCFE0FF)
        val text = c(if (night) 0xFFEDEDED else 0xFF1B1B1F)
        val subText = c(if (night) 0xFFA8ABB3 else 0xFF5C5F66)
        val accent = c(0xFF4C8DF6)
        private fun c(v: Long): Int = v.toInt()
    }

    private val main = Handler(Looper.getMainLooper())
    private val io: ExecutorService = Executors.newSingleThreadExecutor()
    private val observerThread = HandlerThread("screenshot-observer")
    private val thumbCache = LruCache<String, Bitmap>(24)

    private lateinit var store: ClipStore
    private lateinit var clipboard: ClipboardHelper
    private lateinit var cm: ClipboardManager
    private lateinit var observer: ScreenshotObserver
    private lateinit var palette: Palette

    private lateinit var clipScroll: HorizontalScrollView
    private lateinit var clipRow: LinearLayout
    private lateinit var keysContainer: LinearLayout

    private var shift = Shift.OFF
    private var mode = Mode.LETTERS
    private var repeatRunnable: Runnable? = null

    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener {
        try {
            val clip = cm.primaryClip ?: return@OnPrimaryClipChangedListener
            if (clip.itemCount == 0) return@OnPrimaryClipChangedListener
            val d = clip.description
            if (d.hasMimeType(ClipDescription.MIMETYPE_TEXT_PLAIN) || d.hasMimeType(ClipDescription.MIMETYPE_TEXT_HTML)) {
                store.addText(clip.getItemAt(0).coerceToText(this).toString())
            }
        } catch (_: SecurityException) {
            // Clipboard not readable right now; ignore.
        }
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate() {
        super.onCreate()
        store = ClipStore(this)
        clipboard = ClipboardHelper(this)
        cm = getSystemService(ClipboardManager::class.java)
        store.onChanged = { main.post { if (::clipRow.isInitialized) refreshClipBar() } }
        cm.addPrimaryClipChangedListener(clipListener)

        observerThread.start()
        observer = ScreenshotObserver(this, Handler(observerThread.looper)) { onScreenshotDetected(it) }
        observer.register()
    }

    override fun onDestroy() {
        observer.unregister()
        observerThread.quitSafely()
        cm.removePrimaryClipChangedListener(clipListener)
        store.onChanged = null
        io.shutdown()
        super.onDestroy()
    }

    override fun onCreateInputView(): View {
        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        palette = Palette(night)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(palette.bg)
            setPadding(dp(4), dp(4), dp(4), dp(6))
        }
        clipRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        clipScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(clipRow)
        }
        root.addView(clipScroll, ViewGroup.LayoutParams.MATCH_PARENT, dp(64))

        keysContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(keysContainer, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        buildKeyboard()
        refreshClipBar()
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        if (!::keysContainer.isInitialized) return
        mode = Mode.LETTERS
        shift = Shift.OFF
        buildKeyboard()
        updateAutoCaps()
        clipScroll.visibility = if (isPassword(info)) View.GONE else View.VISIBLE
        refreshClipBar()
    }

    // ---------------------------------------------------------------- screenshots

    private fun onScreenshotDetected(uri: Uri) {
        io.execute {
            val id = UUID.randomUUID().toString()
            // The MediaStore row can appear before the file is fully written: retry a few times.
            var name: String? = null
            for (attempt in 0 until 4) {
                name = clipboard.cacheImage(uri, id)
                if (name != null) break
                Thread.sleep(400)
            }
            val cached = name?.let { File(clipboard.cacheDir, it) }
            if (!store.addImage(id, uri.toString(), name)) {
                cached?.delete()
                return@execute
            }
            clipboard.copyImageToClipboard(uri, cached)
        }
    }

    private fun pasteImage(item: ClipItem) {
        io.execute {
            val file = clipboard.ensureCached(item)
            if (file != null && item.cachedName != file.name) store.updateCached(item.id, file.name)
            main.post {
                if (file == null) {
                    toast(R.string.toast_no_access)
                    requestPhotoAccess()
                    return@post
                }
                when (clipboard.paste(currentInputConnection, currentInputEditorInfo, file)) {
                    ClipboardHelper.PasteResult.PASTED -> Unit
                    ClipboardHelper.PasteResult.COPIED -> toast(R.string.toast_copied)
                    ClipboardHelper.PasteResult.FAILED -> toast(R.string.toast_failed)
                }
            }
        }
    }

    private fun requestPhotoAccess() {
        startActivity(Intent(this, PermissionActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    // ---------------------------------------------------------------- clipboard bar

    private fun refreshClipBar() {
        clipRow.removeAllViews()
        if (!Permissions.hasFullAccess(this)) {
            clipRow.addView(textChip(getString(R.string.allow_access), palette.accent) { requestPhotoAccess() })
        }
        val items = store.snapshot()
        if (items.isEmpty()) {
            clipRow.addView(TextView(this).apply {
                text = getString(R.string.clip_empty)
                setTextColor(palette.subText)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                setPadding(dp(8), 0, dp(8), 0)
            })
            return
        }
        if (items.any { !it.pinned }) {
            clipRow.addView(textChip("🗑", palette.chip, width = 44) { store.clearUnpinned() })
        }
        items.forEach { clipRow.addView(chipFor(it)) }
    }

    private fun textChip(label: String, bg: Int, width: Int = 150, onClick: () -> Unit) =
        TextView(this).apply {
            text = label
            gravity = Gravity.CENTER
            setTextColor(if (bg == palette.accent) 0xFFFFFFFF.toInt() else palette.text)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            background = rounded(bg, dp(12))
            layoutParams = LinearLayout.LayoutParams(dp(width), dp(56)).apply { setMargins(dp(3), 0, dp(3), 0) }
            setPadding(dp(6), 0, dp(6), 0)
            setOnClickListener { onClick() }
        }

    private fun chipFor(item: ClipItem): View {
        val chip = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(if (item.pinned) palette.pinned else palette.chip, dp(12))
            setPadding(dp(8), dp(6), dp(8), dp(6))
            layoutParams = LinearLayout.LayoutParams(dp(140), dp(56)).apply { setMargins(dp(3), 0, dp(3), 0) }
            setOnClickListener { onChipTap(item) }
            setOnLongClickListener {
                it.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                store.togglePin(item.id)
                true
            }
        }
        val pin = if (item.pinned) "📌 " else ""

        if (item.type == ClipItem.Type.TEXT) {
            chip.addView(TextView(this).apply {
                text = pin + item.text.orEmpty().trim().replace('\n', ' ')
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
                setTextColor(palette.text)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            })
        } else {
            val iv = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                background = rounded(palette.key, dp(8))
                clipToOutline = true
            }
            chip.addView(iv, dp(40), dp(40))
            loadThumb(item, iv)
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(8), 0, 0, 0)
            }
            col.addView(TextView(this).apply {
                text = pin + getString(R.string.screenshot)
                setTextColor(palette.text)
                setTypeface(typeface, Typeface.BOLD)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                maxLines = 1
            })
            col.addView(TextView(this).apply {
                text = getString(R.string.tap_to_paste)
                setTextColor(palette.accent)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                maxLines = 1
            })
            chip.addView(col)
        }
        return chip
    }

    private fun onChipTap(item: ClipItem) {
        when (item.type) {
            ClipItem.Type.TEXT -> commit(item.text.orEmpty())
            ClipItem.Type.IMAGE -> pasteImage(item)
        }
    }

    private fun loadThumb(item: ClipItem, iv: ImageView) {
        thumbCache.get(item.id)?.let { iv.setImageBitmap(it); return }
        iv.tag = item.id
        io.execute {
            val bmp = try {
                val src = item.cachedName
                    ?.let { File(clipboard.cacheDir, it) }
                    ?.takeIf { it.exists() }
                    ?.let { ImageDecoder.createSource(it) }
                    ?: ImageDecoder.createSource(contentResolver, Uri.parse(item.mediaUri))
                ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
                    decoder.setTargetSampleSize(maxOf(1, maxOf(info.size.width, info.size.height) / 200))
                }
            } catch (_: Exception) {
                null
            }
            if (bmp != null) {
                thumbCache.put(item.id, bmp)
                main.post { if (iv.tag == item.id) iv.setImageBitmap(bmp) }
            }
        }
    }

    // ---------------------------------------------------------------- keys

    private fun buildKeyboard() {
        stopRepeat()
        keysContainer.removeAllViews()
        val letters = mode == Mode.LETTERS

        row { "qwertyuiop1234567890".let { if (letters) it.take(10) else it.takeLast(10) }.forEach { addView(charKey(it)) } }
        row {
            if (letters) addView(spacer(0.5f))
            (if (letters) "asdfghjkl" else "@#\$%&-+()/").forEach { addView(charKey(it)) }
            if (letters) addView(spacer(0.5f))
        }
        row {
            if (letters) addView(key(shiftLabel(), 1.5f, special = true) { cycleShift() })
            else addView(key("~", 1.5f, special = true) { commit("~") })
            (if (letters) "zxcvbnm" else "*\"':;!?").forEach { addView(charKey(it)) }
            addView(key("⌫", 1.5f, special = true, repeat = true) { backspace() })
        }
        row {
            addView(key(if (letters) "?123" else "ABC", 1.5f, special = true) {
                mode = if (letters) Mode.SYMBOLS else Mode.LETTERS
                buildKeyboard()
            })
            addView(key("🌐", 1f, special = true) { switchKeyboard() })
            addView(key(",", 1f) { commit(",") })
            addView(key("", 4f) { commit(" ") })
            addView(key(".", 1f) { commit(".") })
            addView(key("⏎", 1.5f, special = true) { enter() })
        }
    }

    private fun row(build: LinearLayout.() -> Unit) {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        r.build()
        keysContainer.addView(r, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    private fun spacer(weight: Float) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(0, dp(48), weight)
    }

    private fun charKey(c: Char): View {
        val out = if (mode == Mode.LETTERS && shift != Shift.OFF) c.uppercaseChar() else c
        return key(out.toString(), 1f) { commit(out.toString()) }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun key(
        label: String,
        weight: Float,
        special: Boolean = false,
        repeat: Boolean = false,
        action: () -> Unit
    ): TextView = TextView(this).apply {
        text = label
        gravity = Gravity.CENTER
        setTextColor(palette.text)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, if (label.length > 2) 14f else 20f)
        background = pressable(if (special) palette.special else palette.key, palette.keyPressed, dp(8))
        layoutParams = LinearLayout.LayoutParams(0, dp(48), weight).apply { setMargins(dp(2), dp(3), dp(2), dp(3)) }
        contentDescription = if (label.isBlank()) "space" else label
        setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.isPressed = true
                    v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    action()
                    if (repeat) startRepeat(action)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.isPressed = false
                    stopRepeat()
                }
            }
            true
        }
    }

    private fun startRepeat(action: () -> Unit) {
        stopRepeat()
        val r = object : Runnable {
            override fun run() {
                action()
                main.postDelayed(this, 45)
            }
        }
        repeatRunnable = r
        main.postDelayed(r, 400)
    }

    private fun stopRepeat() {
        repeatRunnable?.let { main.removeCallbacks(it) }
        repeatRunnable = null
    }

    // ---------------------------------------------------------------- typing

    private fun commit(s: String) {
        currentInputConnection?.commitText(s, 1)
        updateAutoCaps()
    }

    private fun backspace() {
        sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        updateAutoCaps()
    }

    private fun enter() {
        val opts = currentInputEditorInfo?.imeOptions ?: 0
        val action = opts and EditorInfo.IME_MASK_ACTION
        val noEnterAction = (opts and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noEnterAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            currentInputConnection?.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
        updateAutoCaps()
    }

    private fun switchKeyboard() {
        if (!switchToNextInputMethod(false)) {
            getSystemService(InputMethodManager::class.java).showInputMethodPicker()
        }
    }

    private fun shiftLabel() = when (shift) {
        Shift.OFF -> "⇧"
        Shift.ONCE -> "⬆"
        Shift.LOCKED -> "⇪"
    }

    private fun cycleShift() = setShift(
        when (shift) {
            Shift.OFF -> Shift.ONCE
            Shift.ONCE -> Shift.LOCKED
            Shift.LOCKED -> Shift.OFF
        }
    )

    private fun setShift(s: Shift) {
        if (s != shift) {
            shift = s
            buildKeyboard()
        }
    }

    private fun updateAutoCaps() {
        if (shift == Shift.LOCKED || mode != Mode.LETTERS) return
        val caps = currentInputConnection?.getCursorCapsMode(currentInputEditorInfo?.inputType ?: 0) ?: 0
        setShift(if (caps != 0) Shift.ONCE else Shift.OFF)
    }

    private fun isPassword(info: EditorInfo?): Boolean {
        val t = info?.inputType ?: return false
        val cls = t and InputType.TYPE_MASK_CLASS
        val v = t and InputType.TYPE_MASK_VARIATION
        return (cls == InputType.TYPE_CLASS_TEXT &&
            (v == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                v == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                v == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD)) ||
            (cls == InputType.TYPE_CLASS_NUMBER && v == InputType.TYPE_NUMBER_VARIATION_PASSWORD)
    }

    // ---------------------------------------------------------------- helpers

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(res: Int) = Toast.makeText(this, res, Toast.LENGTH_SHORT).show()

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
    }

    private fun pressable(normal: Int, pressed: Int, radius: Int) = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_pressed), rounded(pressed, radius))
        addState(intArrayOf(), rounded(normal, radius))
    }
}
