# Huawei Keyboard Fix

Open-source Android keyboard (`InputMethodService`) with a clipboard-history bar whose main job is to make
**screenshot copy/paste work on Huawei/Honor devices without Google Play Services**, where Gboard fails
with a "no authorisation" error.

- minSdk 28 · targetSdk 34 · package `com.huaweikeyboard.fix` · Kotlin, no third-party libraries except `androidx.core`
- License: MIT

## How the fix works

1. `ScreenshotObserver` watches `MediaStore.Images.Media.EXTERNAL_CONTENT_URI` and detects a new image whose
   name or folder contains "screenshot" (e.g. `Pictures/Screenshots`).
2. The image bytes are immediately copied (lossless) to `filesDir/screenshots/`, a folder owned by the app.
3. `ClipData.newUri(contentResolver, "screenshot", mediaStoreUri)` is put on the clipboard.
   If that throws `SecurityException` (the Huawei case), the app falls back to the **FileProvider URI of its own copy**.
4. The clipboard bar shows a thumbnail with **Tap to paste**. Tapping pastes via
   `InputConnection.commitContent(..., INPUT_CONTENT_GRANT_READ_URI_PERMISSION)` when the target field accepts images,
   otherwise it puts the FileProvider URI on the clipboard.
5. Long-press a chip to pin / unpin it. 🗑 clears unpinned items.

## Differences from the original spec (on purpose)

| Spec | What is done instead | Why |
|---|---|---|
| `takePersistableUriPermission` on the MediaStore URI | Not used | It only works for Storage Access Framework URIs and throws on MediaStore URIs. A read grant is passed at paste time instead. |
| "HMS permission dialog" | Standard runtime dialog via a transparent `PermissionActivity` | No separate HMS dialog exists; an IME also can't show dialogs itself. |
| `ClipData.newPlainText` in the fallback | FileProvider `ClipData.newUri` | Plain text can't carry an image. |
| `MediaStore.Images.Media.getBitmap()` | Raw stream copy | `getBitmap` is deprecated and re-encoding loses quality. |
| `READ_MEDIA_IMAGES` only | Also `READ_EXTERNAL_STORAGE` (maxSdk 32) | Needed on Android 9–12 (minSdk 28). |
| `SECURITY_DIAGNOSE` | Not declared | Not needed. |

## Setup on the phone

1. Install the APK, open the app.
2. Tap **Enable keyboard**, then **Select keyboard**.
3. Tap **Grant photo access** and choose **Allow all** (Android 14's "Select photos" can't see new screenshots).
4. Huawei/Honor: Settings › Battery › App launch › this app › manage manually (all toggles on).
5. If pasting into some app still fails, turn on **Always paste from the keyboard's own copy**.

## Build

GitHub Actions builds a debug APK on every push (`.github/workflows/build.yml`) and uploads it as an artifact.
Locally: `gradle assembleDebug` (Gradle 8.5, JDK 17). Add the Gradle wrapper with `gradle wrapper` if you want one.

## Known limitations

- Only an English QWERTY layout for now; adding layouts means adding rows in `KeyboardService.buildKeyboard()`.
- Screenshots are detected only while the keyboard service is alive (it is, while it is the selected keyboard).
- Clipboard history is stored in app-private storage, unencrypted. The bar is hidden in password fields.
- No suggestions, swipe typing or emoji picker yet.

## Contributing

PRs welcome: new layouts (Arabic, AZERTY), key-popups, themes, tests.
